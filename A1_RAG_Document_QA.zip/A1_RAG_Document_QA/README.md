# Assignment 1 - Document Question Answering using RAG

## Folder structure
- `Assignment1_RAG_Report.docx` - the written report (submit this)
- `code/rag_qa.py`   - the full RAG system (load -> chunk -> index -> retrieve -> answer)
- `code/evaluate.py` - evaluation (Hit Rate@k, MRR, answer match)
- `data/`            - three sample documents (you can add your own .txt / .md / .pdf)
- `requirements.txt`

## How to run
```
pip install scikit-learn numpy pypdf
cd code
python rag_qa.py --question "What is the pass mark for a course?"
python rag_qa.py              # interactive mode
python evaluate.py            # evaluation tables used in the report
```

## Optional upgrades (need internet)
```
pip install sentence-transformers anthropic
export ANTHROPIC_API_KEY=your_key_here
python rag_qa.py --mode embed --llm claude
```
`--mode embed` uses neural sentence embeddings; `--llm claude` lets Claude write the final answer.
The default mode (TF-IDF + extractive answer) works fully offline and is the version that was
tested and used for the results in the report.
