"""
evaluate.py - measures how good the retriever is.

Metric 1: Hit Rate@k  -> is the correct source file inside the top-k results AND
                         does one of the retrieved chunks contain the key phrase?
Metric 2: MRR         -> Mean Reciprocal Rank of the first correct chunk.
Metric 3: Answer match-> does the final answer contain the key phrase?
"""
from rag_qa import build_system, answer_question

# (question, correct source file, key phrase that must be in the correct chunk/answer)
TEST_SET = [
    ("What is the minimum attendance needed to sit for the final exam?", "university_handbook.txt", "80 percent"),
    ("What is the pass mark for a course?",                              "university_handbook.txt", "40 percent"),
    ("How much is the library fine per day?",                            "university_handbook.txt", "20 rupees"),
    ("How many books can a student borrow?",                             "university_handbook.txt", "5 books"),
    ("How many credits are needed to graduate?",                         "university_handbook.txt", "120 credits"),
    ("What is the penalty for late assignment submission?",              "university_handbook.txt", "10 percent"),
    ("What does TF-IDF stand for?",                                      "nlp_basics.txt",          "Inverse Document Frequency"),
    ("What is hallucination in LLMs?",                                   "nlp_basics.txt",          "hallucination"),
    ("Which paper introduced the Transformer?",                          "nlp_basics.txt",          "Attention Is All You Need"),
    ("How is the closeness of two vectors measured?",                    "nlp_basics.txt",          "cosine similarity"),
    ("What are the two phases of a RAG system?",                         "rag_notes.txt",           "indexing"),
    ("What is a good chunk size for beginners?",                         "rag_notes.txt",           "200 to 500 words"),
    ("What is top-k?",                                                   "rag_notes.txt",           "top-k"),
    ("Name some popular vector databases.",                              "rag_notes.txt",           "FAISS"),
]


def run(k=3, chunk_size=60, overlap=15, mode="tfidf", verbose=False):
    retriever, _, n_chunks = build_system(mode=mode, chunk_size=chunk_size, overlap=overlap)
    hits, rr_sum, ans_ok = 0, 0.0, 0
    for q, src, phrase in TEST_SET:
        answer, results = answer_question(retriever, q, k)
        rank = None
        for i, (_, c) in enumerate(results, 1):
            if c["source"] == src and phrase.lower() in c["text"].lower():
                rank = i
                break
        hits += rank is not None
        rr_sum += 1 / rank if rank else 0
        ans_ok += phrase.lower() in answer.lower()
        if verbose:
            print(f"{'HIT ' if rank else 'MISS'} rank={rank}  {q}")
    n = len(TEST_SET)
    return {"chunks": n_chunks, "hit_rate": hits / n, "mrr": rr_sum / n, "answer_match": ans_ok / n}


if __name__ == "__main__":
    print("=== Detailed run (k=3, chunk_size=60, overlap=15) ===")
    r = run(verbose=True)
    print(f"\nHit Rate@3 = {r['hit_rate']:.2f} | MRR = {r['mrr']:.2f} | Answer match = {r['answer_match']:.2f}\n")

    print("=== Effect of chunk size and k ===")
    print(f"{'chunk':>6} {'overlap':>8} {'k':>3} {'chunks':>7} {'HitRate':>8} {'MRR':>6} {'AnsMatch':>9}")
    for cs, ov in [(30, 8), (60, 15), (100, 25), (200, 50)]:
        for k in (1, 3):
            r = run(k=k, chunk_size=cs, overlap=ov)
            print(f"{cs:>6} {ov:>8} {k:>3} {r['chunks']:>7} {r['hit_rate']:>8.2f} {r['mrr']:>6.2f} {r['answer_match']:>9.2f}")
