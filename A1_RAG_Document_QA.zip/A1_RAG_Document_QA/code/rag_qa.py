"""
rag_qa.py  -  Document Question Answering using RAG (Retrieval-Augmented Generation)

Pipeline (same order as in the report):
    1. Load documents      (.txt / .md / .pdf)
    2. Chunk documents     (small overlapping pieces of text)
    3. Create an index     (TF-IDF vectors  OR  sentence-embedding vectors)
    4. Retrieve            (top-k most similar chunks for the question)
    5. Generate answer     (simple extractive answer  OR  Claude LLM)

Run examples:
    python rag_qa.py --question "What is the pass mark for a course?"
    python rag_qa.py                                   (interactive mode)
    python rag_qa.py --mode embed --llm claude         (needs internet + API key)
"""
import argparse
import glob
import os
import re

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")


# ----------------------------------------------------------------------
# STEP 1 : Load documents
# ----------------------------------------------------------------------
def load_documents(folder):
    """Read every .txt / .md / .pdf file in the folder. Returns {filename: text}."""
    docs = {}
    for path in sorted(glob.glob(os.path.join(folder, "*"))):
        name = os.path.basename(path)
        if path.endswith((".txt", ".md")):
            with open(path, encoding="utf-8") as f:
                docs[name] = f.read()
        elif path.endswith(".pdf"):
            from pypdf import PdfReader          # pip install pypdf
            reader = PdfReader(path)
            docs[name] = "\n".join((p.extract_text() or "") for p in reader.pages)
    return docs


# ----------------------------------------------------------------------
# STEP 2 : Chunking
# ----------------------------------------------------------------------
def chunk_text(text, source, chunk_size=60, overlap=15):
    """
    Split text into chunks of about `chunk_size` words.
    Each new chunk starts (chunk_size - overlap) words after the previous one,
    so neighbouring chunks share `overlap` words.
    """
    words = text.split()
    step = chunk_size - overlap
    chunks = []
    for start in range(0, len(words), step):
        piece = words[start:start + chunk_size]
        if len(piece) < 10 and chunks:           # skip a tiny tail
            break
        chunks.append({"source": source, "id": len(chunks), "text": " ".join(piece)})
    return chunks


# ----------------------------------------------------------------------
# STEP 3 + 4 : Index and retrieve
# ----------------------------------------------------------------------
class Retriever:
    def __init__(self, chunks, mode="tfidf"):
        self.chunks = chunks
        self.mode = mode
        texts = [c["text"] for c in chunks]
        if mode == "tfidf":
            self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2),
                                              sublinear_tf=True)
            self.matrix = self.vectorizer.fit_transform(texts)
        elif mode == "embed":
            from sentence_transformers import SentenceTransformer   # pip install sentence-transformers
            self.model = SentenceTransformer("all-MiniLM-L6-v2")
            self.matrix = self.model.encode(texts, normalize_embeddings=True)
        else:
            raise ValueError("mode must be 'tfidf' or 'embed'")

    def search(self, question, k=3):
        """Return the top-k chunks as a list of (score, chunk)."""
        if self.mode == "tfidf":
            q_vec = self.vectorizer.transform([question])
        else:
            q_vec = self.model.encode([question], normalize_embeddings=True)
        scores = cosine_similarity(q_vec, self.matrix)[0]
        best = np.argsort(scores)[::-1][:k]
        return [(float(scores[i]), self.chunks[i]) for i in best]


# ----------------------------------------------------------------------
# STEP 5 : Generate the answer
# ----------------------------------------------------------------------
def split_sentences(text):
    parts = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text)]
    # keep only complete sentences (a chunk can end in the middle of a sentence)
    return [s for s in parts if len(s) > 15 and s[-1] in ".!?"]


def extractive_answer(question, results, n_sentences=2):
    """
    Offline 'generator': pick the sentences from the retrieved chunks that are
    most similar to the question. No LLM is needed.
    """
    sentences = []
    for _, chunk in results:
        sentences.extend(split_sentences(chunk["text"]))
    sentences = list(dict.fromkeys(sentences))          # remove duplicates, keep order
    if not sentences:
        return "I could not find the answer in the documents."
    vec = TfidfVectorizer(stop_words="english").fit(sentences + [question])
    scores = cosine_similarity(vec.transform([question]), vec.transform(sentences))[0]
    if scores.max() == 0:
        return "I could not find the answer in the documents."
    top = sorted(np.argsort(scores)[::-1][:n_sentences])  # keep original order
    return " ".join(sentences[i] for i in top)


def build_prompt(question, results):
    context = "\n\n".join(f"[Source: {c['source']}]\n{c['text']}" for _, c in results)
    return (
        "Answer the question using ONLY the context below. "
        "If the answer is not in the context, say 'I don't know based on the documents.'\n\n"
        f"CONTEXT:\n{context}\n\nQUESTION: {question}\nANSWER:"
    )


def claude_answer(question, results):
    """LLM generator. Needs:  pip install anthropic   and   ANTHROPIC_API_KEY set."""
    import anthropic
    client = anthropic.Anthropic()                       # reads ANTHROPIC_API_KEY
    reply = client.messages.create(
        model=os.environ.get("CLAUDE_MODEL", "claude-sonnet-5-5"),
        max_tokens=400,
        messages=[{"role": "user", "content": build_prompt(question, results)}],
    )
    return reply.content[0].text


# ----------------------------------------------------------------------
# Putting everything together
# ----------------------------------------------------------------------
def build_system(folder=DATA_DIR, mode="tfidf", chunk_size=60, overlap=15):
    docs = load_documents(folder)
    chunks = []
    for name, text in docs.items():
        chunks.extend(chunk_text(text, name, chunk_size, overlap))
    return Retriever(chunks, mode), len(docs), len(chunks)


def answer_question(retriever, question, k=3, llm="none"):
    results = retriever.search(question, k)
    if llm == "claude":
        answer = claude_answer(question, results)
    else:
        answer = extractive_answer(question, results)
    return answer, results


def main():
    ap = argparse.ArgumentParser(description="RAG document question answering")
    ap.add_argument("--data", default=DATA_DIR, help="folder that contains the documents")
    ap.add_argument("--mode", default="tfidf", choices=["tfidf", "embed"])
    ap.add_argument("--llm", default="none", choices=["none", "claude"])
    ap.add_argument("--k", type=int, default=3, help="number of chunks to retrieve")
    ap.add_argument("--chunk-size", type=int, default=60)
    ap.add_argument("--overlap", type=int, default=15)
    ap.add_argument("--question", help="ask one question and exit")
    args = ap.parse_args()

    retriever, n_docs, n_chunks = build_system(args.data, args.mode, args.chunk_size, args.overlap)
    print(f"Loaded {n_docs} documents -> {n_chunks} chunks  (mode={args.mode}, llm={args.llm})\n")

    def ask(q):
        answer, results = answer_question(retriever, q, args.k, args.llm)
        print(f"Question : {q}")
        print(f"Answer   : {answer}")
        print("Sources  :")
        for score, c in results:
            print(f"   - {c['source']} (chunk {c['id']}, score {score:.3f})")
        print()

    if args.question:
        ask(args.question)
    else:
        print("Type your question (or 'quit' to stop).")
        while True:
            q = input("> ").strip()
            if q.lower() in ("quit", "exit", ""):
                break
            ask(q)


if __name__ == "__main__":
    main()
