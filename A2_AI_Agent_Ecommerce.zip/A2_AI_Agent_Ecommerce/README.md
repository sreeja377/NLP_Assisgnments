# Assignment 2 - AI Agents for an E-commerce Application

## Folder structure
- `Assignment2_AI_Agent_Ecommerce_Report.docx` - the written report (submit this)
- `code/shop_tools.py`       - the 9 tools (search, stock, cart, order, track, cancel ...)
- `code/agent_rule_based.py` - offline agent (rules decide the tool) - needs no API key
- `code/agent_llm.py`        - LLM agent (Claude decides the tool) - needs an API key
- `code/demo.py`             - scripted conversation that prints Thought / Action / Observation
- `code/test_agent.py`       - 10 unit tests
- `data/`                    - products.json (15 products) and orders.json
- `demo_output.txt`          - the output of demo.py used in the report

## How to run (pure Python 3, no install needed)
```
cd code
python demo.py                      # watch the agent work
python agent_rule_based.py          # chat with the agent yourself
python -m unittest test_agent -v    # run the tests
```

## LLM agent (optional)
```
pip install anthropic
export ANTHROPIC_API_KEY=your_key_here
python agent_llm.py
```
The unit tests check the LLM loop with a fake client, so they pass without internet.
The real Claude call itself was not run while preparing this package (no API key available).
