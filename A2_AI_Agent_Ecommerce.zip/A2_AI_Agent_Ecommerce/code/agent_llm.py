"""
agent_llm.py - The same shop, but now an LLM (Claude) is the brain.

Difference from agent_rule_based.py:
    * We do NOT write rules. We only describe the tools (TOOL_SCHEMAS).
    * Claude reads the customer message, decides which tool to call and with which
      arguments, reads the result, and finally writes a natural reply.
    * The loop keeps running while Claude asks for tools (stop_reason == "tool_use").

Needs:   pip install anthropic     and     ANTHROPIC_API_KEY set in the environment.
"""
import json
import os
from shop_tools import Shop, TOOL_SCHEMAS

SYSTEM_PROMPT = """You are a friendly shopping assistant for an online store in Sri Lanka.
Prices are in Sri Lankan rupees (Rs.). Use the tools to look up real data - never invent
products, prices, stock or order status. Before calling place_order, show the cart total and
ask the customer to confirm. If a tool returns an error, explain it simply and suggest an
alternative. Keep answers short."""

MAX_STEPS = 8        # safety limit so the agent can never loop forever


class LLMShoppingAgent:
    def __init__(self, client=None, shop=None, verbose=True):
        if client is None:
            import anthropic
            client = anthropic.Anthropic()
        self.client = client
        self.shop = shop or Shop()
        self.verbose = verbose
        self.model = os.environ.get("CLAUDE_MODEL", "claude-sonnet-5-5")
        self.messages = []                      # conversation memory

    def handle(self, user_message):
        self.messages.append({"role": "user", "content": user_message})
        for _ in range(MAX_STEPS):
            response = self.client.messages.create(
                model=self.model, max_tokens=800, system=SYSTEM_PROMPT,
                tools=TOOL_SCHEMAS, messages=self.messages)
            self.messages.append({"role": "assistant", "content": response.content})

            if response.stop_reason != "tool_use":          # Claude has the final answer
                return "".join(b.text for b in response.content if b.type == "text")

            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    if self.verbose:
                        print(f"    [Action] {block.name}({block.input})")
                    try:
                        result = self.shop.call(block.name, **block.input)
                    except Exception as e:                  # never crash; tell the LLM
                        result = {"error": str(e)}
                    if self.verbose:
                        print(f"    [Observation] {str(result)[:150]}")
                    tool_results.append({"type": "tool_result", "tool_use_id": block.id,
                                         "content": json.dumps(result)})
            self.messages.append({"role": "user", "content": tool_results})
        return "Sorry, I could not finish that request. Please try again."


if __name__ == "__main__":
    agent = LLMShoppingAgent()
    print("LLM shopping agent ready. Type 'quit' to stop.")
    while True:
        msg = input("You: ").strip()
        if msg.lower() in ("quit", "exit"):
            break
        print("Agent:", agent.handle(msg))
