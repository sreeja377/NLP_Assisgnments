"""
agent_rule_based.py - A simple AI shopping agent that works OFFLINE (no API key).

It follows the classic agent loop:
        PERCEIVE (read the message) -> THINK (find the intent) -> ACT (call a tool)
        -> OBSERVE (read the tool result) -> RESPOND (reply to the customer)

The "brain" here is a set of rules (regular expressions). In agent_llm.py the brain
is replaced by a Large Language Model, but the tools and the loop stay the same.
"""
import re
from shop_tools import Shop, tokens


class ShoppingAgent:
    def __init__(self, shop=None, verbose=True):
        self.shop = shop or Shop()
        self.verbose = verbose
        self.last_results = []          # memory: products shown in the last search
        self.last_product = None        # memory: the product we talked about last
        self.pending_checkout = False   # memory: waiting for the customer to confirm

    # ------------------------------------------------------------------
    def act(self, tool, **args):
        """Call a tool and print the Thought/Action/Observation trace."""
        result = self.shop.call(tool, **args)
        if self.verbose:
            print(f"    [Action]      {tool}({args})")
            print(f"    [Observation] {str(result)[:160]}")
        return result

    def think(self, text):
        if self.verbose:
            print(f"    [Thought]     {text}")

    # ------------------------------------------------------------------
    def find_product(self, text):
        """Understand which product the customer means (id, 'first one', or name)."""
        m = re.search(r"\b(\d{3})\b", text)
        if m and int(m.group(1)) in self.shop.products:
            return int(m.group(1))
        ordinals = {"first": 0, "1st": 0, "second": 1, "2nd": 1, "third": 2, "3rd": 2}
        for word, idx in ordinals.items():
            if re.search(rf"\b{word}\b", text) and idx < len(self.last_results):
                return self.last_results[idx]["id"]
        words = set(tokens(text)) - {"cart", "add", "buy", "stock", "available", "price", "details", "about", "remove"}
        best, best_score = None, 0
        for p in self.shop.products.values():
            score = len(words & set(tokens(p["name"])))
            if score > best_score:
                best, best_score = p["id"], score
        if best:
            return best
        if re.search(r"\b(it|that|this)\b", text) and self.last_product:
            return self.last_product
        return None

    # ------------------------------------------------------------------
    def handle(self, message):
        """Main entry: take one customer message and return the reply."""
        text = message.lower().strip()
        if self.verbose:
            print(f"\nCustomer: {message}")

        # --- waiting for yes/no after "shall I place the order?"
        if self.pending_checkout:
            self.pending_checkout = False
            if re.search(r"\b(yes|yeah|confirm|ok|okay|sure|place it)\b", text):
                self.think("Customer confirmed, so I can place the order.")
                r = self.act("place_order")
                return self._say(f"Done! Your order {r['order_id']} for Rs. {r['total']} has been placed." if "error" not in r else r["error"])
            return self._say("No problem, I have not placed the order. Your cart is still saved.")

        # --- track / cancel order
        m = re.search(r"\bord\d+\b", text)
        if m and re.search(r"cancel", text):
            self.think("Customer wants to cancel an order -> cancel_order")
            r = self.act("cancel_order", order_id=m.group().upper())
            return self._say(r["error"] if "error" in r else f"Order {r['order_id']} is now cancelled.")
        if m or re.search(r"\b(track|where is my order|order status)\b", text):
            if not m:
                return self._say("Please tell me your order number (for example ORD1001).")
            self.think("Customer asks about an order -> track_order")
            r = self.act("track_order", order_id=m.group().upper())
            return self._say(r["error"] if "error" in r else f"Order {r['order_id']} is '{r['status']}'. {r['details']}.")

        # --- checkout
        if re.search(r"\b(checkout|check out|place (the |my )?order|buy (it )?now|pay)\b", text):
            self.think("Customer wants to buy. First look at the cart, then ask for confirmation.")
            cart = self.act("view_cart")
            if not cart["items"]:
                return self._say("Your cart is empty. Tell me what you would like to buy.")
            self.pending_checkout = True
            return self._say(f"Your cart total is Rs. {cart['cart_total']}. Shall I place the order? (yes/no)")

        # --- cart
        if re.search(r"\b(remove|delete)\b", text):
            pid = self.find_product(text)
            if pid:
                self.think(f"Customer wants to remove product {pid} -> remove_from_cart")
                r = self.act("remove_from_cart", product_id=pid)
                return self._say(r["error"] if "error" in r else f"Removed. New cart total is Rs. {r['cart_total']}.")
        if re.search(r"\b(add|put)\b.*\bcart\b|\bbuy\b", text):
            pid = self.find_product(text)
            qty_m = re.search(r"\b(\d{1,2})\s*(x|pcs|pieces|items)\b|\bqty\s*(\d+)", text)
            qty = int(next(g for g in qty_m.groups() if g and g.isdigit())) if qty_m else 1
            if not pid:
                return self._say("Which product would you like to add? You can say its name or id.")
            self.think(f"Customer wants product {pid} (qty {qty}). Check stock automatically inside add_to_cart.")
            r = self.act("add_to_cart", product_id=pid, quantity=qty)
            self.last_product = pid
            return self._say(r["error"] if "error" in r else f"Added {qty} x {r['added']} to your cart. Cart total: Rs. {r['cart_total']}.")

        if re.search(r"\b(my cart|view cart|show cart|show my cart|what.?s in (my|the) cart)\b", text):
            self.think("Customer wants to see the cart -> view_cart")
            r = self.act("view_cart")
            if not r["items"]:
                return self._say("Your cart is empty.")
            lines = [f"  - {i['name']} x{i['qty']} = Rs. {i['line_total']}" for i in r["items"]]
            return self._say("Your cart:\n" + "\n".join(lines) + f"\n  Total: Rs. {r['cart_total']}")
        # --- stock / details
        if re.search(r"\b(in stock|available|availability|stock)\b", text):
            pid = self.find_product(text)
            if pid:
                self.think("Customer asks about availability -> check_stock")
                r = self.act("check_stock", product_id=pid)
                self.last_product = pid
                return self._say(f"{r['name']}: {r['stock']} units in stock." if r["in_stock"] else f"Sorry, {r['name']} is out of stock.")
        if re.search(r"\b(details|tell me more|describe|about)\b", text):
            pid = self.find_product(text)
            if pid:
                self.think("Customer wants more information -> get_product_details")
                r = self.act("get_product_details", product_id=pid)
                self.last_product = pid
                return self._say(f"{r['name']} (Rs. {r['price']}): {r['description']}. Stock: {r['stock']}.")

        # --- greeting / help
        if re.search(r"^(hi|hello|hey|help)\b", text):
            return self._say("Hello! I can search products, check stock, manage your cart, place orders and track orders. What do you need?")

        # --- default: product search
        price_m = re.search(r"(?:under|below|less than|within|max(?:imum)?)\s*(?:rs\.?|lkr)?\s*(\d[\d,]*)", text)
        max_price = int(price_m.group(1).replace(",", "")) if price_m else None
        category = next((c for c in ["electronics", "clothing", "footwear", "home", "books", "stationery"] if c in text), None)
        query = re.sub(r"(?:under|below|less than|within|max(?:imum)?)\s*(?:rs\.?|lkr)?\s*\d[\d,]*", "", text)
        self.think(f"Looks like a product search: query='{query.strip()}', max_price={max_price}, category={category}")
        r = self.act("search_products", query=query, max_price=max_price, category=category)
        self.last_results = r["products"]
        if not r["products"]:
            return self._say("Sorry, I could not find any matching product. Try different words or a higher budget.")
        lines = [f"  {i}. [{p['id']}] {p['name']} - Rs. {p['price']}{'' if p['in_stock'] else ' (OUT OF STOCK)'}"
                 for i, p in enumerate(r["products"], 1)]
        return self._say("I found these products:\n" + "\n".join(lines))

    def _say(self, reply):
        if self.verbose:
            print(f"Agent   : {reply}")
        return reply


if __name__ == "__main__":
    agent = ShoppingAgent(verbose=False)
    print("Shopping agent ready. Type 'quit' to stop.")
    while True:
        msg = input("You: ").strip()
        if msg.lower() in ("quit", "exit"):
            break
        print("Agent:", agent.handle(msg))
