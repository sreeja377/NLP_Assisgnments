"""demo.py - runs a full scripted shopping conversation and prints the agent's reasoning trace."""
from agent_rule_based import ShoppingAgent

agent = ShoppingAgent(verbose=True)
conversation = [
    "Hi",
    "I am looking for a wireless mouse under 3000",
    "Is the first one in stock?",
    "Add it to my cart",
    "Show me electronics under 5000",
    "add the second one to cart",   # tests the memory of the last search results
    "show my cart",
    "add 2 x 201 to cart",
    "remove 201 from cart",
    "checkout",
    "yes",
    "Where is my order ORD1001?",
    "Cancel ORD1002",
    "Cancel ORD1001",
    "Do you have the USB-C hub in stock?",
    "Add USB-C hub to my cart",
]
for msg in conversation:
    agent.handle(msg)
