"""
shop_tools.py  -  The "tools" (hands) of our e-commerce agent.

An AI agent does not touch the database directly. It calls small, well defined
functions called TOOLS. Each tool takes simple inputs and returns a dictionary.
The same tools are used by both agents in this project:
    - agent_rule_based.py  (no API key needed)
    - agent_llm.py         (Claude decides which tool to call)
"""
import copy
import json
import os
import re

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")
STOP = {"a", "an", "the", "for", "with", "and", "or", "of", "to", "me", "my", "i", "some", "any",
        "good", "best", "need", "want", "show", "find", "looking", "please", "under", "below", "in"}


def tokens(text):
    return [w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOP]


class Shop:
    """Holds the shop data (products, orders) and the customer's cart."""

    def __init__(self):
        with open(os.path.join(DATA, "products.json")) as f:
            self.products = {p["id"]: p for p in json.load(f)}
        with open(os.path.join(DATA, "orders.json")) as f:
            self.orders = {o["order_id"]: o for o in json.load(f)}
        self.cart = {}                      # {product_id: quantity}
        self._next_order = 1003

    # ---------------- Tool 1 ----------------
    def search_products(self, query="", max_price=None, category=None):
        """Search the catalogue by keywords, optional maximum price and category."""
        words = set(tokens(query))
        found = []
        for p in self.products.values():
            if category and category.lower() != p["category"].lower():
                continue
            if max_price is not None and p["price"] > max_price:
                continue
            text = set(tokens(p["name"] + " " + p["description"] + " " + p["category"]))
            score = len(words & text)
            if words and score == 0:
                continue
            found.append((score, p))
        found.sort(key=lambda t: (-t[0], t[1]["price"]))
        return {"count": len(found), "products": [self._brief(p) for _, p in found[:5]]}

    # ---------------- Tool 2 ----------------
    def get_product_details(self, product_id):
        p = self.products.get(int(product_id))
        return p if p else {"error": f"Product {product_id} not found"}

    # ---------------- Tool 3 ----------------
    def check_stock(self, product_id):
        p = self.products.get(int(product_id))
        if not p:
            return {"error": f"Product {product_id} not found"}
        return {"product_id": p["id"], "name": p["name"], "stock": p["stock"], "in_stock": p["stock"] > 0}

    # ---------------- Tool 4 ----------------
    def add_to_cart(self, product_id, quantity=1):
        p = self.products.get(int(product_id))
        if not p:
            return {"error": f"Product {product_id} not found"}
        quantity = int(quantity)
        if quantity < 1:
            return {"error": "Quantity must be at least 1"}
        already = self.cart.get(p["id"], 0)
        if already + quantity > p["stock"]:
            return {"error": f"Only {p['stock']} of '{p['name']}' in stock (cart already has {already})"}
        self.cart[p["id"]] = already + quantity
        return {"added": p["name"], "quantity": quantity, "cart_total": self._cart_total()}

    # ---------------- Tool 5 ----------------
    def view_cart(self):
        items = [{"product_id": pid, "name": self.products[pid]["name"], "qty": q,
                  "line_total": self.products[pid]["price"] * q} for pid, q in self.cart.items()]
        return {"items": items, "cart_total": self._cart_total()}

    # ---------------- Tool 6 ----------------
    def remove_from_cart(self, product_id):
        pid = int(product_id)
        if pid not in self.cart:
            return {"error": f"Product {pid} is not in the cart"}
        del self.cart[pid]
        return {"removed": pid, "cart_total": self._cart_total()}

    # ---------------- Tool 7 ----------------
    def place_order(self):
        if not self.cart:
            return {"error": "Your cart is empty"}
        order_id = f"ORD{self._next_order}"
        self._next_order += 1
        items = [{"product_id": pid, "qty": q} for pid, q in self.cart.items()]
        total = self._cart_total()
        for pid, q in self.cart.items():          # reduce stock
            self.products[pid]["stock"] -= q
        self.orders[order_id] = {"order_id": order_id, "items": items, "total": total,
                                 "status": "Processing", "tracking": "Order received, packing in progress"}
        self.cart = {}
        return {"order_id": order_id, "total": total, "status": "Processing"}

    # ---------------- Tool 8 ----------------
    def track_order(self, order_id):
        o = self.orders.get(order_id.upper())
        if not o:
            return {"error": f"Order {order_id} not found"}
        return {"order_id": o["order_id"], "status": o["status"], "details": o["tracking"], "total": o["total"]}

    # ---------------- Tool 9 ----------------
    def cancel_order(self, order_id):
        o = self.orders.get(order_id.upper())
        if not o:
            return {"error": f"Order {order_id} not found"}
        if o["status"] != "Processing":
            return {"error": f"Order {o['order_id']} is '{o['status']}' and can no longer be cancelled"}
        o["status"] = "Cancelled"
        for it in o["items"]:                     # give the stock back
            self.products[it["product_id"]]["stock"] += it["qty"]
        return {"order_id": o["order_id"], "status": "Cancelled"}

    # ---------------- helpers ----------------
    def _cart_total(self):
        return sum(self.products[pid]["price"] * q for pid, q in self.cart.items())

    @staticmethod
    def _brief(p):
        return {"id": p["id"], "name": p["name"], "category": p["category"], "price": p["price"],
                "in_stock": p["stock"] > 0}

    def call(self, name, **kwargs):
        """Run a tool by its name (used by both agents)."""
        return getattr(self, name)(**kwargs)


# JSON descriptions of the tools. The LLM reads these to know what it can call.
TOOL_SCHEMAS = [
    {"name": "search_products", "description": "Search the product catalogue. Use for any product request. Prices are in Sri Lankan rupees (LKR).",
     "input_schema": {"type": "object", "properties": {
         "query": {"type": "string", "description": "keywords, e.g. 'wireless mouse'"},
         "max_price": {"type": "number", "description": "maximum price in LKR"},
         "category": {"type": "string", "description": "Electronics, Clothing, Footwear, Home, Books or Stationery"}}}},
    {"name": "get_product_details", "description": "Get full details of one product by its id.",
     "input_schema": {"type": "object", "properties": {"product_id": {"type": "integer"}}, "required": ["product_id"]}},
    {"name": "check_stock", "description": "Check whether a product is in stock.",
     "input_schema": {"type": "object", "properties": {"product_id": {"type": "integer"}}, "required": ["product_id"]}},
    {"name": "add_to_cart", "description": "Add a product to the shopping cart.",
     "input_schema": {"type": "object", "properties": {"product_id": {"type": "integer"}, "quantity": {"type": "integer"}}, "required": ["product_id"]}},
    {"name": "view_cart", "description": "Show the cart and its total.", "input_schema": {"type": "object", "properties": {}}},
    {"name": "remove_from_cart", "description": "Remove a product from the cart.",
     "input_schema": {"type": "object", "properties": {"product_id": {"type": "integer"}}, "required": ["product_id"]}},
    {"name": "place_order", "description": "Buy everything in the cart. Only call after the customer clearly confirms.", "input_schema": {"type": "object", "properties": {}}},
    {"name": "track_order", "description": "Get the status of an order, e.g. ORD1001.",
     "input_schema": {"type": "object", "properties": {"order_id": {"type": "string"}}, "required": ["order_id"]}},
    {"name": "cancel_order", "description": "Cancel an order that is still in 'Processing' status.",
     "input_schema": {"type": "object", "properties": {"order_id": {"type": "string"}}, "required": ["order_id"]}},
]
