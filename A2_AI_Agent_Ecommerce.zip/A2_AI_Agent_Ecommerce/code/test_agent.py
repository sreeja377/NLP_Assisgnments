"""Unit tests. Run:  python -m unittest test_agent -v     (no API key needed)"""
import unittest
from types import SimpleNamespace as NS
from shop_tools import Shop
from agent_rule_based import ShoppingAgent
from agent_llm import LLMShoppingAgent


class TestTools(unittest.TestCase):
    def setUp(self):
        self.shop = Shop()

    def test_search_price_filter(self):
        r = self.shop.search_products("mouse", max_price=1000)
        self.assertEqual(r["count"], 0)
        r = self.shop.search_products("mouse", max_price=3000)
        self.assertEqual(r["products"][0]["id"], 101)

    def test_out_of_stock_cannot_be_added(self):
        self.assertIn("error", self.shop.add_to_cart(103))

    def test_cannot_exceed_stock(self):
        self.assertIn("error", self.shop.add_to_cart(204, 6))   # only 5 in stock

    def test_order_reduces_stock_and_clears_cart(self):
        self.shop.add_to_cart(101, 2)
        r = self.shop.place_order()
        self.assertEqual(r["total"], 3980)
        self.assertEqual(self.shop.products[101]["stock"], 23)
        self.assertEqual(self.shop.cart, {})

    def test_empty_cart_order(self):
        self.assertIn("error", self.shop.place_order())

    def test_cancel_returns_stock(self):
        before = self.shop.products[401]["stock"]
        self.shop.cancel_order("ORD1002")
        self.assertEqual(self.shop.products[401]["stock"], before + 1)

    def test_cannot_cancel_shipped(self):
        self.assertIn("error", self.shop.cancel_order("ORD1001"))


class TestRuleAgent(unittest.TestCase):
    def test_full_flow_needs_confirmation(self):
        a = ShoppingAgent(verbose=False)
        a.handle("find wireless mouse")
        a.handle("add the first one to my cart")
        reply = a.handle("checkout")
        self.assertIn("Shall I place the order", reply)
        self.assertEqual(len(a.shop.orders), 2)            # nothing placed yet
        a.handle("yes")
        self.assertEqual(len(a.shop.orders), 3)

    def test_declining_keeps_cart(self):
        a = ShoppingAgent(verbose=False)
        a.handle("add 101 to my cart")
        a.handle("checkout")
        a.handle("no")
        self.assertEqual(a.shop.cart, {101: 1})


class TestLLMLoopWithFakeClaude(unittest.TestCase):
    """Checks our loop logic using a fake client that behaves like Claude (no internet)."""
    def test_tool_loop(self):
        replies = [
            NS(stop_reason="tool_use", content=[NS(type="tool_use", id="t1", name="search_products",
                                                   input={"query": "mouse"})]),
            NS(stop_reason="end_turn", content=[NS(type="text", text="I found the Logitech mouse for Rs. 1990.")]),
        ]
        client = NS(messages=NS(create=lambda **kw: replies.pop(0)))
        agent = LLMShoppingAgent(client=client, verbose=False)
        self.assertIn("1990", agent.handle("I need a mouse"))
        self.assertEqual(agent.messages[2]["content"][0]["type"], "tool_result")


if __name__ == "__main__":
    unittest.main()
