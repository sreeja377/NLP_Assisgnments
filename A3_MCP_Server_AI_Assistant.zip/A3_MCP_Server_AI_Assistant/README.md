# Assignment 3 - Build an MCP Server for an AI Assistant

## Folder structure
- `Assignment3_MCP_Server_Report.docx` - the written report (submit this)
- `code/server.py`        - the MCP server (7 tools, 2 resources, 1 prompt)
- `code/client_test.py`   - a test client that starts the server and calls everything
- `client_test_output.txt`- real output of client_test.py (used in the report)
- `claude_desktop_config.example.json` - how to connect the server to Claude Desktop

## How to run
```
pip install mcp
cd code
python client_test.py        # starts the server automatically and tests all features
```
`server.py` works with the new `mcp` 2.x package (MCPServer) and has a fallback for 1.x (FastMCP).
It was tested with mcp 2.3.0. The 1.x fallback import was not run here.

## Connect to Claude Desktop
1. Open Claude Desktop -> Settings -> Developer -> Edit Config.
2. Copy the content of `claude_desktop_config.example.json` into `claude_desktop_config.json`
   and change the path to where you saved `server.py`.
3. Restart Claude Desktop. The tools appear under the tools/connectors icon.
4. Ask: "Save a note: submit report on Friday", then "What notes do I have?".

## Debug with the MCP Inspector (optional, needs Node.js)
```
npx @modelcontextprotocol/inspector python code/server.py
```
