"""
client_test.py - A small MCP CLIENT that starts server.py and tests everything.

This is what Claude Desktop does behind the scenes:
    1. start the server as a child process (stdio transport)
    2. initialize  (handshake)
    3. list tools / resources / prompts
    4. call tools, read resources, get prompts
"""
import asyncio
import os
import sys
import tempfile

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

HERE = os.path.dirname(os.path.abspath(__file__))


def text_of(result):
    return "".join(c.text for c in result.content if getattr(c, "type", "") == "text")


async def main():
    notes_file = os.path.join(tempfile.mkdtemp(), "notes_test.json")      # test with a fresh file
    params = StdioServerParameters(command=sys.executable, args=[os.path.join(HERE, "server.py")],
                                   env={**os.environ, "NOTES_FILE": notes_file})

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            print("=== 1. TOOLS offered by the server ===")
            for t in (await session.list_tools()).tools:
                print(f" - {t.name}: {t.description}")

            print("\n=== 2. CALLING TOOLS ===")
            calls = [("add_note", {"title": "NLP assignment", "content": "Submit MCP report on Friday"}),
                     ("add_note", {"title": "Shopping", "content": "Buy notebook and pen"}),
                     ("list_notes", {}),
                     ("search_notes", {"keyword": "friday"}),
                     ("calculate", {"expression": "(12 + 8) * 3 / 4"}),
                     ("calculate", {"expression": "__import__('os').system('ls')"}),   # attack attempt
                     ("calculate", {"expression": "10 / 0"}),
                     ("convert_units", {"value": 100, "from_unit": "celsius", "to_unit": "fahrenheit"}),
                     ("convert_units", {"value": 5, "from_unit": "km", "to_unit": "miles"}),
                     ("get_current_time", {"timezone": "Asia/Colombo"}),
                     ("delete_note", {"note_id": 2}),
                     ("delete_note", {"note_id": 99})]
            for name, args in calls:
                result = await session.call_tool(name, args)
                print(f" {name}({args})\n    -> {text_of(result)}")

            print("\n=== 3. RESOURCES ===")
            for r in (await session.list_resources()).resources:
                print(f" - {r.uri}")
            for t in (await session.list_resource_templates()).resource_templates:
                print(f" - template: {t.uri_template}")
            res = await session.read_resource("notes://1")
            print(" notes://1 ->", res.contents[0].text.replace("\n", " "))

            print("\n=== 4. PROMPTS ===")
            for p in (await session.list_prompts()).prompts:
                print(f" - {p.name}")
            prompt = await session.get_prompt("summarize_notes", {"style": "a numbered list"})
            print(" ->", prompt.messages[0].content.text)


asyncio.run(main())
