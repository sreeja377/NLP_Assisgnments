"""
server.py - A personal-assistant MCP server.

MCP (Model Context Protocol) lets an AI assistant (Claude Desktop, an IDE, your own app)
connect to external tools and data in a standard way. A server can offer 3 things:

    TOOLS      - functions the AI can CALL        (add_note, calculate, ...)
    RESOURCES  - data the AI can READ             (notes://all)
    PROMPTS    - ready-made prompt templates      (summarize_notes)

Run it directly:      python server.py            (waits for an MCP client on stdin/stdout)
Test it:              python client_test.py
"""
import ast
import json
import operator
import os
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

# The official SDK renamed FastMCP to MCPServer in version 2. Support both.
try:
    from mcp.server.mcpserver import MCPServer as FastMCP      # mcp >= 2.0
except ImportError:
    from mcp.server.fastmcp import FastMCP                     # mcp 1.x

mcp = FastMCP("personal-assistant")

NOTES_FILE = os.environ.get("NOTES_FILE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "notes.json"))


# ---------------------------------------------------------------- storage helpers
def load_notes():
    if not os.path.exists(NOTES_FILE):
        return []
    with open(NOTES_FILE, encoding="utf-8") as f:
        return json.load(f)


def save_notes(notes):
    with open(NOTES_FILE, "w", encoding="utf-8") as f:
        json.dump(notes, f, indent=2)


# ---------------------------------------------------------------- TOOLS : notes
@mcp.tool()
def add_note(title: str, content: str) -> str:
    """Save a new note. Returns the id of the note."""
    notes = load_notes()
    note_id = max((n["id"] for n in notes), default=0) + 1
    notes.append({"id": note_id, "title": title, "content": content,
                  "created": datetime.now().isoformat(timespec="seconds")})
    save_notes(notes)
    return f"Note {note_id} saved."


@mcp.tool()
def list_notes() -> str:
    """List the id and title of all saved notes."""
    notes = load_notes()
    if not notes:
        return "No notes yet."
    return "\n".join(f"{n['id']}: {n['title']}" for n in notes)


@mcp.tool()
def search_notes(keyword: str) -> str:
    """Find notes whose title or content contains the keyword (not case sensitive)."""
    k = keyword.lower()
    hits = [n for n in load_notes() if k in n["title"].lower() or k in n["content"].lower()]
    if not hits:
        return f"No notes contain '{keyword}'."
    return "\n".join(f"{n['id']}: {n['title']} - {n['content']}" for n in hits)


@mcp.tool()
def delete_note(note_id: int) -> str:
    """Delete the note with the given id."""
    notes = load_notes()
    remaining = [n for n in notes if n["id"] != note_id]
    if len(remaining) == len(notes):
        return f"Note {note_id} not found."
    save_notes(remaining)
    return f"Note {note_id} deleted."


# ---------------------------------------------------------------- TOOLS : calculator
# We never use eval() on user text (dangerous). We walk the syntax tree and allow only maths.
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
        ast.USub: operator.neg, ast.UAdd: operator.pos}


def _eval(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        if isinstance(node.op, ast.Pow) and abs(_eval(node.right)) > 100:
            raise ValueError("exponent too large")
        return _OPS[type(node.op)](_eval(node.left), _eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_eval(node.operand))
    raise ValueError("only numbers and + - * / ** % are allowed")


@mcp.tool()
def calculate(expression: str) -> str:
    """Evaluate a maths expression such as '(12 + 8) * 3 / 4'."""
    try:
        return str(_eval(ast.parse(expression, mode="eval").body))
    except ZeroDivisionError:
        return "Error: division by zero"
    except (ValueError, SyntaxError) as e:
        return f"Error: {e}"


# ---------------------------------------------------------------- TOOLS : utilities
@mcp.tool()
def convert_units(value: float, from_unit: str, to_unit: str) -> str:
    """Convert between km/miles, kg/lb and celsius/fahrenheit."""
    f, t = from_unit.lower(), to_unit.lower()
    table = {("km", "miles"): lambda v: v * 0.621371, ("miles", "km"): lambda v: v / 0.621371,
             ("kg", "lb"): lambda v: v * 2.20462, ("lb", "kg"): lambda v: v / 2.20462,
             ("celsius", "fahrenheit"): lambda v: v * 9 / 5 + 32,
             ("fahrenheit", "celsius"): lambda v: (v - 32) * 5 / 9}
    if (f, t) not in table:
        return "Unsupported conversion. Supported: km<->miles, kg<->lb, celsius<->fahrenheit."
    return f"{value} {f} = {table[(f, t)](value):.2f} {t}"


@mcp.tool()
def get_current_time(timezone: str = "Asia/Colombo") -> str:
    """Get the current date and time in an IANA timezone, e.g. 'Asia/Colombo' or 'Europe/London'."""
    try:
        return datetime.now(ZoneInfo(timezone)).strftime("%A, %d %B %Y, %I:%M %p") + f" ({timezone})"
    except ZoneInfoNotFoundError:
        return f"Unknown timezone '{timezone}'."


# ---------------------------------------------------------------- RESOURCES
@mcp.resource("notes://all")
def all_notes_resource() -> str:
    """All notes as JSON text (read-only data for the AI to read)."""
    return json.dumps(load_notes(), indent=2)


@mcp.resource("notes://{note_id}")
def one_note_resource(note_id: str) -> str:
    """A single note by id."""
    for n in load_notes():
        if str(n["id"]) == note_id:
            return json.dumps(n, indent=2)
    return f"Note {note_id} not found."


# ---------------------------------------------------------------- PROMPTS
@mcp.prompt()
def summarize_notes(style: str = "bullet points") -> str:
    """A reusable prompt that asks the AI to summarise all saved notes."""
    return (f"Please read my saved notes (use the list_notes and search_notes tools or the "
            f"notes://all resource) and summarise them as {style}. Mention any deadlines.")


if __name__ == "__main__":
    mcp.run()        # default transport = stdio
